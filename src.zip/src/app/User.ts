export class User {
	private User_ID :number;
	private Name: string;
	private Age:number;
}