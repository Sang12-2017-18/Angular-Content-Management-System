export class Content {
	 C_ID:string;
	 File_or_Link: string;
     Type: string;
     Date_Modified: Date; 
     User_ID: number;

    public setName(name: string) {
    	this.File_or_Link = name;
    }

    public setType(t: string) {
    	this.Type = t;
    }
}