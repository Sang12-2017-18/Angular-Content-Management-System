import { Component, OnInit } from '@angular/core';
import { Content } from './Content';
import { ContentService } from './content.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'cms';
  cont: Content[];
  error='';
  success='';

  constructor(private contentService: ContentService, private route: Router) {
  }
        
  ngOnInit() {
    this.getContent();
  }
        
  getContent(): void {
  	this.contentService.getAll().subscribe(
    (res: Content[]) => {
      this.cont = res;
    },
    (err) => {
      this.error = err;
    }
  );
  }

  deleteContent(id: string):void {
      
     this.contentService.deleteFile(id).subscribe(
       	(res1: string) => {
       		this.success = res1; 
       	},
       	(err) => {
       		this.error = err;
       	}
     );
  }

  gotoPage(): void {
  	setTimeout(() => this.route.navigate(["update"]).then(nav => {
    console.log(nav); // true if navigation is successful
  }, err => {
    console.log(err) // when there's an error
  }), 1000);
  }

}

