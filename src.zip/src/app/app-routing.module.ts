import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UploadComponent } from './upload/upload.component';
import { UpdateComponent } from './update/update.component';
import { AppComponent } from './app.component';


const routes: Routes = [
 
     { 
       		path:'upload',
       		component: UploadComponent,
     },


     { 
  	    path: 'update',
  	    component: UpdateComponent,
     }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule { }
