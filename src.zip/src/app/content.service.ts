import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams, HttpEvent, HttpEventType } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { Content } from './Content';

@Injectable({
  providedIn: 'root'
})

export class ContentService {
	baseURL = 'http://localhost:80/PHPrestapi';
    cont : Content[] = new Array<Content>();
    str1: string;
  constructor(private http: HttpClient) { 
  }
                  
	getAll(): Observable <Content[]> {
  		return this.http.get(`${this.baseURL}/listContent`).pipe(
    	map((res) => {
      		this.cont = res['data'];
      	    return this.cont;
  		}),
  		catchError(this.handleError));
  		
	}

	public uploadFile(data) {
    let uploadURL = `${this.baseURL}/upload`;
    return this.http.post<any>(uploadURL, data);
  }
    
	private handleError(error: HttpErrorResponse) {
       console.log(error.message);
        //this.log('failed: ${error.message}');
       // return an observable with a user friendly message
      return throwError('Error! something went wrong.');
      }

   public deleteFile(data: string) : Observable<string> {
        let deleteURL = `${this.baseURL}/delete`;
        const params1 = new HttpParams().set('id', data);
        //let elem = JSON.stringify(data);
        return this.http.delete(deleteURL,{ params: params1 })
        .pipe(map((res1) => 
        	{
        		let str1 = "Deleted Successfully";
        		return str1;
        	}),
            catchError(this.handleError));
   }
    
    public updateFile(data) {
    	let updateURL = `${this.baseURL}/update`;
    	return this.http.post<any>(updateURL, data);
    }
} 

