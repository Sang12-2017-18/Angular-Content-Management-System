import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from  '@angular/forms';
import { ContentService } from '../content.service';
import { Content } from '../Content';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
	form: FormGroup;
  form1: FormGroup;
  cont: Content[];
  error='';
  fname;
  updateResponse;

  constructor(private formBuilder: FormBuilder, private contentService: ContentService) { }

  ngOnInit() {
  	this.form = this.formBuilder.group({
      idf: ['']
    });
    this.form1 = this.formBuilder.group({
      newfile: ['']
    });
    this.getContent();
  }

  saveName(event):void {
    this.fname=event.target.value;
    console.log(this.fname);
  }

  getContent(): void {
    this.contentService.getAll().subscribe(
    (res: Content[]) => {
      this.cont = res;
    },
    (err) => {
      this.error = err;
    }
  );
  }


  onFileSelect(event) {
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      this.form1.get('newfile').setValue(file);
      console.log(file);
    }
  }

  onSubmit() {
    const formData = new FormData();
    formData.append('idf',this.fname);
    formData.append('newfile', this.form1.get('newfile').value);
    //for(var pair of formData.values()) 
    //      console.log(pair);

    this.contentService.updateFile(formData).subscribe(
      (res) => {
        this.updateResponse = res;
          console.log(res);
      },
      (err) => {  
        console.log(err);
      }
    );
  }

}
